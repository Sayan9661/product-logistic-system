package DesignLab;
import java.util.*;
public class report {
	int items_sold;
	String Dist_Name;
	String Date_Of_Purchase;
	int items_bought;
	report(int items_sold,String Dist_Name,String Date_Of_Purchase,int items_bought)
	{
		this.items_sold=items_sold;
		this.Dist_Name=Dist_Name;
		this.Date_Of_Purchase=Date_Of_Purchase;
		this.items_bought=items_bought;
	}
}