package DesignLab;

public class Inventory {
	Item item[];

}
